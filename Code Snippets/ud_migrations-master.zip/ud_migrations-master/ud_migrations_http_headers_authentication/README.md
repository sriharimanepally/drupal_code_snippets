# Adding HTTP Request Headers and Authentication to remote JSON and XML Drupal migrations

This is not a working module. Instead, its purpose is to provide snippets that
can be used in your own migrations. Please make sure not to disclose any
sensitive data or credentials in a plain text file.

Make sure of *not* committing any sensitive data credentials to the repository.
It is possible to manage migration plugins like configuration. That will allow
you to inject values read from environment variables or user form submissions.
