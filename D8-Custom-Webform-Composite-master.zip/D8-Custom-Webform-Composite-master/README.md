# D8-Custom-Webform-Composite
A custom module that provides custom composite fields for Drupal 8 Webform module.

1. Enable this module
2. Go build a webform
3. You should be able to add "Colleges Attended" and "Employment Info" composite fields to your webform. 

