var input = document.querySelector("#phone");
window.intlTelInput(input, {
  utilsScript: "../../build/js/utils.js?1572003440815" // just for formatting/placeholders etc
});
