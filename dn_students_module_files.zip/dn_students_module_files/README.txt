install dn_students by placing folder dn_students in modules folder.

from extend page, enable/install this module

after installation students table will be created in database.

access module page using URL  https://www.yourdomain.com/admin/structure/dn_students/students/manageStudents

compatable with Drupal 8 and Drupal 9 versions