!function ($) {
 
$(document).ready(function() {
	alert("document ready");
});
}(window.jQuery);	