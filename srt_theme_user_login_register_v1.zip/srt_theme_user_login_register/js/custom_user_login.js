(function($){
 $(document).ready(function(){
// alert("custom_user_login_js");


  // console.log($(".form-gp .form-item input").html());


  /*================================
    login form
    ==================================*/

  $('.form-gp .form-item input').on('focus', function() {
      $(this).parent('.form-gp .form-item').addClass('custom_focused');
  });
  $('.form-gp .form-item input').on('focusout', function() {
      if ($(this).val().length === 0) {
          $(this).parent('.form-gp .form-item').removeClass('custom_focused');
      }
  });


    /*================================
    login form
    ==================================*/
  //   $('.form-gp input').on('focus', function() {
  //     $(this).parent('.form-gp').addClass('focused');
  // });
  // $('.form-gp input').on('focusout', function() {
  //     if ($(this).val().length === 0) {
  //         $(this).parent('.form-gp').removeClass('focused');
  //     }
  // });

 });
})(jQuery);

/* (function ($, Drupal) { */

  'use strict';
  /* CODE GOES HERE */

/* })(jQuery, Drupal); */