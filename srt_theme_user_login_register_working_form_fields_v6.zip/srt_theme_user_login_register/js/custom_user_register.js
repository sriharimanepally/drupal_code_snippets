(function($){


$(document).ready(function(){
     alert("custom user register js");

     $('[data-toggle="tooltip"]').tooltip();
     $(".preloader").fadeOut();




});
})(jQuery);